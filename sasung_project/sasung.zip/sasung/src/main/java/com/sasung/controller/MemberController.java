package com.sasung.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;

import com.sasung.service.InquiryDetailService;
import com.sasung.service.InquiryInsertService;
import com.sasung.service.InquiryListService;
import com.sasung.service.MemberGetService;
import com.sasung.service.MemberService;
import com.sasung.service.OrderInsertService;
import com.sasung.service.MemberInsertService;
import com.sasung.service.MemberLoginService;
import com.sasung.service.MemberLogoutService;

@WebServlet("*.do")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L; 
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");

		String viewPage = "";
		String uri = request.getRequestURI();
		String com = uri.substring(uri.lastIndexOf("/")+1, uri.lastIndexOf(".do"));
		
		if(com!=null && com.equals("index")) {
			viewPage = "/WEB-INF/views/index.jsp";
			
		}else if(com!=null && com.equals("galaxy")) {
			viewPage = "/WEB-INF/views/galaxy.jsp";
			
		}else if(com!=null && com.equals("ai")) {
			viewPage = "/WEB-INF/views/ai.jsp";
			
		}else if(com!=null && com.equals("login")) {
			viewPage = "/WEB-INF/views/login.jsp";
			
		}else if(com!=null && com.equals("mobile")) {
			viewPage = "/WEB-INF/views/mobile.jsp";
			
		}else if(com!=null && com.equals("pc")) {
			viewPage = "/WEB-INF/views/pc.jsp";
			
		}else if(com!=null && com.equals("shop")) {
			viewPage = "/WEB-INF/views/shop.jsp";
			
		}else if(com!=null && com.equals("wash")) {
			viewPage = "/WEB-INF/views/wash.jsp";
			
		}else if(com!=null && com.equals("sign")) {
			viewPage = "/WEB-INF/views/sign.jsp";
			
		}else if(com!=null && com.equals("createUser")) {	
			MemberService service = new MemberInsertService();
			service.execute(request, response);
			viewPage = "/WEB-INF/views/index.jsp";
			System.err.println("디버깅: createUser.do 실행됨");
			
		}else if(com!=null && com.equals("mypage")) {
			MemberService service = new MemberGetService();
			service.execute(request, response);
			viewPage = "/WEB-INF/views/mypage.jsp";
			
		}else if(com!=null && com.equals("se_mobile")) {
			viewPage = "/WEB-INF/views/common/se_mobile.jsp";
			
		}else if(com!=null && com.equals("se_pc")) {
			viewPage = "/WEB-INF/views/common/se_pc.jsp";
			
		}else if(com!=null && com.equals("se_wash")) {
			viewPage = "/WEB-INF/views/common/se_wash.jsp";
//로그인 
		}else if (com != null && com.equals("signIn")) {
		    MemberService service = new MemberLoginService();
		    service.execute(request, response);

		    viewPage = (String) request.getAttribute("viewPage"); // 서비스에서 설정한 페이지
		}else if(com!=null && com.equals("logout")) {
			MemberService service = new MemberLogoutService();
		    service.execute(request, response);
		    viewPage = "/WEB-INF/views/index.jsp";
		}else if(com!=null && com.equals("createOrder")) {
		    MemberService service = new OrderInsertService();
		    service.execute(request, response);
		    viewPage = "/WEB-INF/views/index.jsp";
		}else if(com!=null && com.equals("contact")) {
		    viewPage = "/WEB-INF/views/contact.jsp";
		    
		} else if(com!=null && com.equals("createInquiry")) {
		    MemberService service = new InquiryInsertService();
		    service.execute(request, response);
		    response.sendRedirect("contact.do");
		    return;
		    
		} else if(com!=null && com.equals("myInquiries")) {
		    MemberService service = new InquiryListService();
		    service.execute(request, response);
		    viewPage = "/WEB-INF/views/myInquiries.jsp";
		    
		} else if(com!=null && com.equals("inquiryDetail")) {
		    MemberService service = new InquiryDetailService();
		    service.execute(request, response);
		    viewPage = "/WEB-INF/views/inquiryDetail.jsp";
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(viewPage);
		rd.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
