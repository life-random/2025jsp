package com.sasung.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sasung.member.OrderDAO;
import com.sasung.member.OrderDTO;

public class OrderInsertService implements MemberService {

	@Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        // 폼에서 전송된 데이터 받기
        String productName = request.getParameter("product_name");
        String totalAmountStr = request.getParameter("total_amount");
        String recipientName = request.getParameter("recipient_name");
        String recipientPhone = request.getParameter("recipient_phone");
        String recipientEmail = request.getParameter("recipient_email");
        String deliveryAddress = request.getParameter("delivery_address");
        
        // 문자열을 숫자로 변환
        long totalAmount = Long.parseLong(totalAmountStr);
        
      //디버깅: 콘솔에 출력
      		System.out.println("product_name: " + productName);
      		System.out.println("total_amount: " + totalAmountStr);
      		System.out.println("recipient_name: " + recipientName);
      		System.out.println("recipient_phone: " + recipientPhone);
      		System.out.println("recipient_email: " + recipientEmail);
      		System.out.println("delivery_address: " + deliveryAddress);
        
        // DTO 생성
        OrderDTO dto = new OrderDTO(productName, totalAmount, recipientName, 
                                   recipientPhone, recipientEmail, deliveryAddress);
        
        // DAO를 통해 데이터베이스에 저장
        OrderDAO dao = new OrderDAO();
        dao.insertOrder(dto);
        
        // 주문 정보를 request에 저장 (주문 완료 페이지에서 사용)
        request.setAttribute("order", dto);
    }
}
