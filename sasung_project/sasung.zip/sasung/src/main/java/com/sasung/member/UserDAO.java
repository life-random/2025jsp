package com.sasung.member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class UserDAO {
	// DB연동 커넥션 생성
	private Connection getConnection() throws Exception {

		// connection pool을 활용한 db연동
		Context initCtx = new InitialContext();
		Context envCtx = (Context) initCtx.lookup("java:comp/env");
		DataSource ds = (DataSource) envCtx.lookup("jdbc/jskim");
		Connection con = ds.getConnection();

		return con;
	}

	// 데이터베이스에 데이터 저장
	public void insert(UserDTO dto) {
		String sql = "INSERT INTO users(email,pwd,name,birthdate) VALUES(?,?,?,?)";
		try (Connection con = getConnection(); PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, dto.getEmail());
			pstmt.setString(2, dto.getPwd());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getBirthdate());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public UserDTO get(String email) {
		String sql = "select * from users where email = ?";
		UserDTO dto = null;
		try (Connection con = getConnection(); PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, email);
			ResultSet rs = pstmt.executeQuery();
//예외처리
			if (rs.next()) {
			    String name = rs.getString("name");
			    String pwd = rs.getString("pwd");
			    String birthdate = rs.getString("birthdate");
			    dto = new UserDTO(email, name, pwd, birthdate);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto;
	}

	public UserDTO login(String email, String pwd) {
		String sql = "SELECT * FROM users WHERE email = ? AND pwd = ?";
		UserDTO dto = null;

		try (Connection con = getConnection(); PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, email);
			pstmt.setString(2, pwd);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				String name = rs.getString("name");
				String birthdate = rs.getString("birthdate");
				dto = new UserDTO(email, name, pwd, birthdate);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return dto;
	}

}
