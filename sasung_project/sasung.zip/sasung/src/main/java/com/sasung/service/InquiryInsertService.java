package com.sasung.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sasung.member.InquiryDAO;
import com.sasung.member.InquiryDTO;

public class InquiryInsertService implements MemberService {

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        // 폼에서 전송된 데이터 받기
        String userName = request.getParameter("userName");
        String userEmail = request.getParameter("userEmail");
        String inquiryType = request.getParameter("inquiryType");
        String subject = request.getParameter("inquirySubject");
        String message = request.getParameter("inquiryMessage");
        String attachmentFile = request.getParameter("attachmentFile"); // 파일 업로드는 추후 구현
        
        // 디버깅용 출력
        System.out.println("=== 문의 등록 정보 ===");
        System.out.println("이름: " + userName);
        System.out.println("이메일: " + userEmail);
        System.out.println("문의 유형: " + inquiryType);
        System.out.println("제목: " + subject);
        System.out.println("내용: " + message);
        
        // DTO 생성
        InquiryDTO dto = new InquiryDTO(userName, userEmail, inquiryType, subject, message, attachmentFile);
        
        // DAO를 통해 데이터베이스에 저장
        InquiryDAO dao = new InquiryDAO();
        dao.insertInquiry(dto);
        
        // 성공 메시지 설정
        request.setAttribute("message", "문의가 성공적으로 등록되었습니다.");
    }
}