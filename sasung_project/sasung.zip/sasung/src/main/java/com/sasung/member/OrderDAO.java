package com.sasung.member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class OrderDAO {
    
    // DB연동 커넥션 생성
    private Connection getConnection() throws Exception {
        Context initCtx = new InitialContext();
        Context envCtx = (Context) initCtx.lookup("java:comp/env");
        DataSource ds = (DataSource) envCtx.lookup("jdbc/jskim");
        Connection con = ds.getConnection();
        return con;
    }
    
    // 주문 정보 저장
    public void insertOrder(OrderDTO dto) {
        String sql = "INSERT INTO orders(product_name, total_amount, recipient_name, recipient_phone, recipient_email, delivery_address) VALUES(?,?,?,?,?,?)";
        
        try (Connection con = getConnection(); 
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            
            pstmt.setString(1, dto.getProductName());
            pstmt.setLong(2, dto.getTotalAmount());
            pstmt.setString(3, dto.getRecipientName());
            pstmt.setString(4, dto.getRecipientPhone());
            pstmt.setString(5, dto.getRecipientEmail());
            pstmt.setString(6, dto.getDeliveryAddress());
            
            pstmt.executeUpdate();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // 특정 사용자의 주문 목록 조회
    public java.util.List<OrderDTO> getOrdersByEmail(String email) {
        String sql = "SELECT * FROM orders WHERE recipient_email = ? ORDER BY order_time DESC";
        java.util.List<OrderDTO> orders = new java.util.ArrayList<>();
        
        try (Connection con = getConnection(); 
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                OrderDTO dto = new OrderDTO();
                dto.setOrderId(rs.getLong("order_id"));
                dto.setProductName(rs.getString("product_name"));
                dto.setTotalAmount(rs.getLong("total_amount"));
                dto.setRecipientName(rs.getString("recipient_name"));
                dto.setRecipientPhone(rs.getString("recipient_phone"));
                dto.setRecipientEmail(rs.getString("recipient_email"));
                dto.setDeliveryAddress(rs.getString("delivery_address"));
                dto.setOrderTime(rs.getString("order_time"));
                orders.add(dto);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return orders;
    }
}