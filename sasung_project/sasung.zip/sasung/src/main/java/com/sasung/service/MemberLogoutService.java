package com.sasung.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javax.servlet.http.HttpSession;
public class MemberLogoutService implements MemberService {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// 세션 무효화
		HttpSession session = request.getSession(false);
	    if (session != null) {
	        session.invalidate();
	    }
	}

}
