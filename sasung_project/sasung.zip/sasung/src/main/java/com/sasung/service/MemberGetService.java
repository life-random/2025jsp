package com.sasung.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sasung.member.UserDAO;
import com.sasung.member.UserDTO;

public class MemberGetService implements MemberService {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String email = request.getParameter("email");
		UserDTO dto = new UserDTO();
		UserDAO dao = new UserDAO();
		
		dto = dao.get(email);
		request.setAttribute("dto", dto);
	}
}
