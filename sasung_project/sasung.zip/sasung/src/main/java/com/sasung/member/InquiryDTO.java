package com.sasung.member;

public class InquiryDTO {
	private long inquiryId;
	private String userName;
	private String userEmail;
	private String inquiryType;
	private String subject;
	private String message;
	private String attachmentFile;
	private String status;
	private String createdAt;
	private String updatedAt;

	// 답변 관련 필드 (조인용)
	private String answerContent;
	private String adminName;
	private String answeredAt;

	// 기본 생성자
	public InquiryDTO() {
	}

	// 문의 작성용 생성자
	public InquiryDTO(String userName, String userEmail, String inquiryType, String subject, String message,
			String attachmentFile) {
		this.userName = userName;
		this.userEmail = userEmail;
		this.inquiryType = inquiryType;
		this.subject = subject;
		this.message = message;
		this.attachmentFile = attachmentFile;
		this.status = "pending"; // 기본값: 답변 대기중
	}

	// 전체 생성자
	public InquiryDTO(long inquiryId, String userName, String userEmail, String inquiryType, String subject,
			String message, String attachmentFile, String status, String createdAt, String updatedAt) {
		this.inquiryId = inquiryId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.inquiryType = inquiryType;
		this.subject = subject;
		this.message = message;
		this.attachmentFile = attachmentFile;
		this.status = status;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}

	// Getter & Setter
	public long getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(long inquiryId) {
		this.inquiryId = inquiryId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getInquiryType() {
		return inquiryType;
	}

	public void setInquiryType(String inquiryType) {
		this.inquiryType = inquiryType;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getAttachmentFile() {
		return attachmentFile;
	}

	public void setAttachmentFile(String attachmentFile) {
		this.attachmentFile = attachmentFile;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	// 답변 관련 getter/setter
	public String getAnswerContent() {
		return answerContent;
	}

	public void setAnswerContent(String answerContent) {
		this.answerContent = answerContent;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAnsweredAt() {
		return answeredAt;
	}

	public void setAnsweredAt(String answeredAt) {
		this.answeredAt = answeredAt;
	}

	// 유틸리티 메서드
	public String getStatusDisplayName() {
		switch (this.status) {
		case "pending":
			return "답변 대기 중";
		case "completed":
			return "답변 완료";
		default:
			return "알 수 없음";
		}
	}

	public String getInquiryTypeDisplayName() {
		switch (this.inquiryType) {
		case "general-inquiry":
			return "일반 문의";
		case "technical-support":
			return "기술 지원";
		case "partnership":
			return "제휴 문의";
		case "bug-report":
			return "버그 제보";
		case "other":
			return "기타";
		default:
			return "기타";
		}
	}
}
