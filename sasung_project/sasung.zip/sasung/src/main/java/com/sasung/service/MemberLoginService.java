package com.sasung.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sasung.member.UserDAO;
import com.sasung.member.UserDTO;

public class MemberLoginService implements MemberService {

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        String email = request.getParameter("email");
        String pwd = request.getParameter("pwd");

        UserDAO dao = new UserDAO();
        UserDTO user = dao.login(email, pwd); // 로그인 성공 시 DTO 반환

        if (user != null) {
            // 로그인 성공 → 세션에 저장
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            request.setAttribute("viewPage", "/WEB-INF/views/index.jsp");
        } else {
            // 로그인 실패 → 메시지 전달
            request.setAttribute("errorMsg", "이메일 또는 비밀번호가 틀렸습니다.");
            request.setAttribute("viewPage", "/WEB-INF/views/loginFail.jsp");
        }
    }
}