package com.sasung.member;

public class OrderDTO {
	private long orderId;
	private String productName;
	private long totalAmount;
	private String recipientName;
	private String recipientPhone;
	private String recipientEmail;
	private String deliveryAddress;
	private String orderTime;

	// 기본 생성자
	public OrderDTO() {
	}

	// 주문 생성용 생성자 (orderId, orderTime 제외)
	public OrderDTO(String productName, long totalAmount, String recipientName, String recipientPhone,
			String recipientEmail, String deliveryAddress) {
		this.productName = productName;
		this.totalAmount = totalAmount;
		this.recipientName = recipientName;
		this.recipientPhone = recipientPhone;
		this.recipientEmail = recipientEmail;
		this.deliveryAddress = deliveryAddress;
	}

	// Getter & Setter
	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public long getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(long totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getRecipientName() {
		return recipientName;
	}

	public void setRecipientName(String recipientName) {
		this.recipientName = recipientName;
	}

	public String getRecipientPhone() {
		return recipientPhone;
	}

	public void setRecipientPhone(String recipientPhone) {
		this.recipientPhone = recipientPhone;
	}

	public String getRecipientEmail() {
		return recipientEmail;
	}

	public void setRecipientEmail(String recipientEmail) {
		this.recipientEmail = recipientEmail;
	}

	public String getDeliveryAddress() {
		return deliveryAddress;
	}

	public void setDeliveryAddress(String deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}
}
