package com.sasung.member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class InquiryDAO {
    
    // DB연동 커넥션 생성
    private Connection getConnection() throws Exception {
        Context initCtx = new InitialContext();
        Context envCtx = (Context) initCtx.lookup("java:comp/env");
        DataSource ds = (DataSource) envCtx.lookup("jdbc/jskim");
        Connection con = ds.getConnection();
        return con;
    }
    
    // 문의 등록
    public void insertInquiry(InquiryDTO dto) {
        String sql = "INSERT INTO inquiries(user_name, user_email, inquiry_type, subject, message, attachment_file) VALUES(?,?,?,?,?,?)";
        
        try (Connection con = getConnection(); 
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            
            pstmt.setString(1, dto.getUserName());
            pstmt.setString(2, dto.getUserEmail());
            pstmt.setString(3, dto.getInquiryType());
            pstmt.setString(4, dto.getSubject());
            pstmt.setString(5, dto.getMessage());
            pstmt.setString(6, dto.getAttachmentFile());
            
            pstmt.executeUpdate();
            System.out.println("문의가 성공적으로 등록되었습니다.");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // 특정 사용자의 문의 목록 조회 (답변 포함)
    public List<InquiryDTO> getInquiriesByEmail(String userEmail) {
        String sql = "SELECT i.*, a.answer_content, a.admin_name, a.answered_at " +
                    "FROM inquiries i " +
                    "LEFT JOIN inquiry_answers a ON i.inquiry_id = a.inquiry_id " +
                    "WHERE i.user_email = ? " +
                    "ORDER BY i.created_at DESC";
        
        List<InquiryDTO> inquiries = new ArrayList<>();
        
        try (Connection con = getConnection(); 
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            
            pstmt.setString(1, userEmail);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                InquiryDTO dto = new InquiryDTO();
                dto.setInquiryId(rs.getLong("inquiry_id"));
                dto.setUserName(rs.getString("user_name"));
                dto.setUserEmail(rs.getString("user_email"));
                dto.setInquiryType(rs.getString("inquiry_type"));
                dto.setSubject(rs.getString("subject"));
                dto.setMessage(rs.getString("message"));
                dto.setAttachmentFile(rs.getString("attachment_file"));
                dto.setStatus(rs.getString("status"));
                dto.setCreatedAt(rs.getString("created_at"));
                dto.setUpdatedAt(rs.getString("updated_at"));
                
                // 답변 정보 (있는 경우)
                dto.setAnswerContent(rs.getString("answer_content"));
                dto.setAdminName(rs.getString("admin_name"));
                dto.setAnsweredAt(rs.getString("answered_at"));
                
                inquiries.add(dto);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return inquiries;
    }
    
    // 전체 문의 목록 조회 (관리자용)
    public List<InquiryDTO> getAllInquiries() {
        String sql = "SELECT i.*, a.answer_content, a.admin_name, a.answered_at " +
                    "FROM inquiries i " +
                    "LEFT JOIN inquiry_answers a ON i.inquiry_id = a.inquiry_id " +
                    "ORDER BY i.created_at DESC";
        
        List<InquiryDTO> inquiries = new ArrayList<>();
        
        try (Connection con = getConnection(); 
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                InquiryDTO dto = new InquiryDTO();
                dto.setInquiryId(rs.getLong("inquiry_id"));
                dto.setUserName(rs.getString("user_name"));
                dto.setUserEmail(rs.getString("user_email"));
                dto.setInquiryType(rs.getString("inquiry_type"));
                dto.setSubject(rs.getString("subject"));
                dto.setMessage(rs.getString("message"));
                dto.setAttachmentFile(rs.getString("attachment_file"));
                dto.setStatus(rs.getString("status"));
                dto.setCreatedAt(rs.getString("created_at"));
                dto.setUpdatedAt(rs.getString("updated_at"));
                
                // 답변 정보
                dto.setAnswerContent(rs.getString("answer_content"));
                dto.setAdminName(rs.getString("admin_name"));
                dto.setAnsweredAt(rs.getString("answered_at"));
                
                inquiries.add(dto);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return inquiries;
    }
    
    // 특정 문의 조회
    public InquiryDTO getInquiryById(long inquiryId) {
        String sql = "SELECT i.*, a.answer_content, a.admin_name, a.answered_at " +
                    "FROM inquiries i " +
                    "LEFT JOIN inquiry_answers a ON i.inquiry_id = a.inquiry_id " +
                    "WHERE i.inquiry_id = ?";
        
        InquiryDTO dto = null;
        
        try (Connection con = getConnection(); 
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            
            pstmt.setLong(1, inquiryId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                dto = new InquiryDTO();
                dto.setInquiryId(rs.getLong("inquiry_id"));
                dto.setUserName(rs.getString("user_name"));
                dto.setUserEmail(rs.getString("user_email"));
                dto.setInquiryType(rs.getString("inquiry_type"));
                dto.setSubject(rs.getString("subject"));
                dto.setMessage(rs.getString("message"));
                dto.setAttachmentFile(rs.getString("attachment_file"));
                dto.setStatus(rs.getString("status"));
                dto.setCreatedAt(rs.getString("created_at"));
                dto.setUpdatedAt(rs.getString("updated_at"));
                
                // 답변 정보
                dto.setAnswerContent(rs.getString("answer_content"));
                dto.setAdminName(rs.getString("admin_name"));
                dto.setAnsweredAt(rs.getString("answered_at"));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return dto;
    }
    
    // 답변 등록 (관리자용)
    public void insertAnswer(long inquiryId, String adminName, String answerContent) {
        String sql1 = "INSERT INTO inquiry_answers(inquiry_id, admin_name, answer_content) VALUES(?,?,?)";
        String sql2 = "UPDATE inquiries SET status = 'completed' WHERE inquiry_id = ?";
        
        try (Connection con = getConnection()) {
            con.setAutoCommit(false); // 트랜잭션 시작
            
            // 답변 등록
            try (PreparedStatement pstmt1 = con.prepareStatement(sql1)) {
                pstmt1.setLong(1, inquiryId);
                pstmt1.setString(2, adminName);
                pstmt1.setString(3, answerContent);
                pstmt1.executeUpdate();
            }
            
            // 문의 상태를 '답변 완료'로 변경
            try (PreparedStatement pstmt2 = con.prepareStatement(sql2)) {
                pstmt2.setLong(1, inquiryId);
                pstmt2.executeUpdate();
            }
            
            con.commit(); // 트랜잭션 커밋
            System.out.println("답변이 성공적으로 등록되었습니다.");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // 문의 상태별 개수 조회
    public int getInquiryCountByStatus(String status) {
        String sql = "SELECT COUNT(*) FROM inquiries WHERE status = ?";
        int count = 0;
        
        try (Connection con = getConnection(); 
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            
            pstmt.setString(1, status);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                count = rs.getInt(1);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return count;
    }
}