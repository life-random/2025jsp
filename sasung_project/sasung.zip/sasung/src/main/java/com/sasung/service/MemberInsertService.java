package com.sasung.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sasung.member.UserDAO;
import com.sasung.member.UserDTO;

public class MemberInsertService implements MemberService {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String id = request.getParameter("email");
		String name = request.getParameter("name");
		String pwd = request.getParameter("pwd");
		String birthdate = request.getParameter("birthdate");
		
		//디버깅: 콘솔에 출력
		System.out.println("email: " + id);
		System.out.println("name: " + name);
		System.out.println("password: " + pwd);
		System.out.println("birthdate: " + birthdate);
		
		UserDTO dto = new UserDTO(id, pwd, name, birthdate);
		UserDAO dao = new UserDAO();
		dao.insert(dto);
	}

}
