package com.sasung.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sasung.member.InquiryDAO;
import com.sasung.member.InquiryDTO;

public class InquiryDetailService implements MemberService {

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        // 문의 ID 파라미터 받기
        String inquiryIdStr = request.getParameter("inquiryId");
        
        if (inquiryIdStr != null && !inquiryIdStr.trim().isEmpty()) {
            try {
                long inquiryId = Long.parseLong(inquiryIdStr);
                
                // 특정 문의 조회
                InquiryDAO dao = new InquiryDAO();
                InquiryDTO inquiry = dao.getInquiryById(inquiryId);
                
                if (inquiry != null) {
                    request.setAttribute("inquiry", inquiry);
                } else {
                    request.setAttribute("errorMsg", "해당 문의를 찾을 수 없습니다.");
                }
                
            } catch (NumberFormatException e) {
                request.setAttribute("errorMsg", "잘못된 문의 ID입니다.");
            }
        } else {
            request.setAttribute("errorMsg", "문의 ID가 필요합니다.");
        }
    }
}