package com.sasung.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sasung.member.InquiryDAO;
import com.sasung.member.InquiryDTO;
import com.sasung.member.UserDTO;

public class InquiryListService implements MemberService {

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        // 세션에서 로그인한 사용자 정보 가져오기
        HttpSession session = request.getSession();
        UserDTO user = (UserDTO) session.getAttribute("user");
        
        if (user != null) {
            // 로그인한 사용자의 문의 목록 조회
            InquiryDAO dao = new InquiryDAO();
            List<InquiryDTO> inquiries = dao.getInquiriesByEmail(user.getEmail());
            
            // request에 문의 목록 저장
            request.setAttribute("inquiries", inquiries);
            
            System.out.println("사용자 " + user.getEmail() + "의 문의 " + inquiries.size() + "건 조회");
        } else {
            // 로그인하지 않은 경우
            request.setAttribute("errorMsg", "로그인이 필요합니다.");
        }
    }
}
