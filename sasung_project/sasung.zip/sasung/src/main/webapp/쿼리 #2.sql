CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    pwd VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    birthdate DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- 기존 테이블 삭제
DROP TABLE IF EXISTS orders;

-- 외래키 없이 테이블 생성
CREATE TABLE orders (
    order_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '주문 아이디',
    product_name VARCHAR(500) NOT NULL COMMENT '상품명',
    total_amount DECIMAL(10,0) NOT NULL COMMENT '최종 결제 금액',
    recipient_name VARCHAR(100) NOT NULL COMMENT '수령인 이름',
    recipient_phone VARCHAR(20) NOT NULL COMMENT '수령인 전화번호',
    recipient_email VARCHAR(255) NOT NULL COMMENT '수령인 이메일',
    delivery_address TEXT NOT NULL COMMENT '배송 주소',
    order_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '주문 시간'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='주문 정보 테이블';

USE frontend;
SHOW TABLES;

SELECT * from users;

SELECT * from orders;

CREATE TABLE inquiries (
    inquiry_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '문의 아이디',
    user_name VARCHAR(100) NOT NULL COMMENT '문의자 이름',
    user_email VARCHAR(255) NOT NULL COMMENT '문의자 이메일',
    inquiry_type VARCHAR(50) NOT NULL COMMENT '문의 유형',
    subject VARCHAR(500) NOT NULL COMMENT '문의 제목',
    message TEXT NOT NULL COMMENT '문의 내용',
    attachment_file VARCHAR(255) NULL COMMENT '첨부파일명',
    status VARCHAR(20) DEFAULT 'pending' COMMENT '답변 상태 (pending: 대기중, completed: 답변완료)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '문의 작성일',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일',
    
    -- 인덱스
    INDEX idx_user_email (user_email),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at),
    INDEX idx_inquiry_type (inquiry_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='문의 게시판 테이블';

-- 문의 답변 테이블 생성
CREATE TABLE inquiry_answers (
    answer_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '답변 아이디',
    inquiry_id BIGINT NOT NULL COMMENT '문의 아이디 (외래키)',
    admin_name VARCHAR(100) NOT NULL COMMENT '답변자 이름',
    answer_content TEXT NOT NULL COMMENT '답변 내용',
    answered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '답변일',
    
    -- 외래키 제약조건
    CONSTRAINT fk_inquiry_answers_inquiry_id 
    FOREIGN KEY (inquiry_id) REFERENCES inquiries(inquiry_id) 
    ON DELETE CASCADE ON UPDATE CASCADE,
    
    -- 인덱스
    INDEX idx_inquiry_id (inquiry_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='문의 답변 테이블';
