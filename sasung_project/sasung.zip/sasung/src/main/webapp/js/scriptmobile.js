// 갤럭시 메뉴 클릭 시 활성화 클래스 적용 함수
function setActive(element) {
  // 모든 갤럭시 메뉴 아이템들 선택
  const items = document.querySelectorAll('.galaxy-item');

  // 모든 아이템에서 active 클래스 제거
  items.forEach(item => item.classList.remove('active'));

  // 클릭된 요소에 active 클래스 추가
  element.classList.add('active');
}

// 페이지 로드 시 첫 번째 갤럭시 메뉴 아이템 활성화 설정
document.addEventListener('DOMContentLoaded', () => {
  const firstItem = document.querySelector('.galaxy-item');
  if (firstItem) firstItem.classList.add('active');
});
